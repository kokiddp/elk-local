CREATE TABLE demo (id INT);
